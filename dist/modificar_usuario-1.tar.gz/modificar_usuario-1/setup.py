from setuptools import setup

setup(
    name='modificar_usuario',
    version='1',
    description='crear, verificar, eliminar usuarios de un diccionario',
    author='Federico Etchevest',
    author_email='federico.etchevest@gmail.com',
    packages=["paquete_segunda_entrega"]
)